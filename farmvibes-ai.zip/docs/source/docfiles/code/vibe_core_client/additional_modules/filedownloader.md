# File Downloader

```{eval-rst}
.. automodule:: vibe_core.file_downloader
   :members:
   :show-inheritance:
```

```{eval-rst}
.. autosummary::
   :toctree: _autosummary
```
